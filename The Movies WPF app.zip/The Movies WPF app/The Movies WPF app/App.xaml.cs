﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace The_Movies_WPF_app
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
