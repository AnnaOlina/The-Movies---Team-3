﻿using System.IO;
using The_Movies_WPF_app.Models;

namespace The_Movies_WPF_app.Repositories
{
    // Definerer offentlig klasse, som overholder IMovieRepository
    public class FileMovieRepository : IMovieRepository
    {
        // Deklarer et felt, der kun kan bruges i klassens konstruktør.
        // Underscore for at tydeliggøre at det er klassens interne felt (navnekonvention)
        private readonly string _filePath;
        public FileMovieRepository()
        {
            // Finder appens basefolder
            var baseDir = AppContext.BaseDirectory;
            // Definerer stien til undermappen "Data"
            var dataDir = Path.Combine(baseDir, "Data");
            // Sørger for at mappen findes i dataDir
            Directory.CreateDirectory(dataDir);
            // Bygger stien til mappen og definerer filnavnet
            _filePath = Path.Combine(dataDir, "movies.csv");

            // Hvis fil ikke findes: Opret fil med header
            if (!File.Exists(_filePath))
            {
                File.WriteAllText(_filePath, "Title,RunTime,Genre" + Environment.NewLine);
            }
        }
        // Genererer sekvens af Movie-objekter
        public IEnumerable<Movie> GetAllMovies()
        {
            // Hvis fil ikke eksisterer: Returner tom sekvens
            if (!File.Exists(_filePath))
                return Enumerable.Empty<Movie>();
            // Bygger en variabel 'movies', som får en ny List<Movie> 
            var movies = new List<Movie>();
            // Starter en løkke, hvor 'line' sættes til hver linje i sekvensen. Skip(1) betyder 'Spring over header'
            foreach (var line in File.ReadAllLines(_filePath).Skip(1))
            {
                // Spring over tomme linjer
                if (string.IsNullOrWhiteSpace(line)) continue;
                // Split linjen ved komma
                var parts = line.Split(',');
                // Spring over linjer, der ikke indeholder 3 elementer, og undgå parsingfejl
                if (parts.Length != 3) continue;
                // Danner lokale variabler, der parses til korrekte datatyper:            
                var title = parts[0];
                var runTime = TimeSpan.Parse(parts[1]);
                var genre = Enum.Parse<MovieGenre>(parts[2]);
                // Tilføjer et Movie-objekt til listen
                movies.Add(new Movie(title, runTime, (MovieGenre)genre));
            }
            return movies;
        }
        // Modtager Movie-objekt og laver en tekstlinje i CSV-format, som appenderes til CSV-filen
        public void AddMovie(Movie movie)
        {
            var line = $"{movie.Title},{movie.RunTime},{movie.Genre}";
            // Appenderer line til _filePath, + platformuafhængig kommando til linjeskift
            File.AppendAllText(_filePath, line + Environment.NewLine);
        }
    }
}
